# Demo folder — how to use it

Everything needed to present the work, in one place.

---

## Importing the report into Notion

`REPORT.md` is plain Markdown. In Notion: **Import → Markdown & CSV**.

To keep the figures, import the **zip of this whole folder** rather than the
`.md` alone — Notion resolves the relative image paths inside a zip. Importing
the file on its own gives the text with broken images.

---

## Running the live demonstration

```powershell
cd ..
.\venv_hunyuan\Scripts\activate
pip install fastapi "uvicorn[standard]" python-multipart
python src\api.py
```

Then open `http://localhost:8000`. From a phone on the same network, use the
machine's IP instead of `localhost` — the API listens on `0.0.0.0`, and the
browser will offer to install the app.

### A five-minute run-through

**1. Start with Replay, not a live photo.** Click *Démonstration*. The default
pair is already a raw reading and its pre-processed counterpart from the
diversified set. Pages `1,2` is a two-page invoice, so the merging step is
visible.

Replay is instant. A live reading takes 30 s to 3 min, and nobody watches a
frozen screen in a meeting.

**2. Walk down the step list.** It is the whole argument in one column:
sheet located, model read, tables merged, arithmetic checked, reading chosen.

**3. Stop on "Décision de fusion".** This is the internship's own
contribution. The panel names the signals that decided each transition —
continuation marker, numbering continuity, closing total. Worth saying out
loud: *zero wrong merges across eight benchmark runs*.

**4. Stop on the line table.** Rows are coloured by arithmetic status. On 215
line items, 6 % are flagged and they contain 100 % of the numeric errors.
That is what makes the result reviewable in practice.

**5. Then, if there is time, a live photo.** Choose *1 seule lecture* for
speed. Point out that the detected sheet outline is drawn on the actual photo:
the localisation is not a black box.

### If a live run is needed and it is slow

- select **HunyuanOCR-1.5 (GPU)** — it already runs on the laptop GPU;
- select **1 seule lecture** — halves the work;
- one page rather than two.

---

## Files

| file | what it is |
|---|---|
| `REPORT.md` | full progress report, English, Notion-ready |
| `figures/` | all figures, generated from measured values |
| `artifacts/sample-invoice.json` | a real pipeline export, nothing hand-edited |
| `artifacts/merge-decisions.txt` | the merge evaluation, decision by decision |

`sample-invoice.json` is worth opening during the meeting: it carries an
explicit `extraction.status` and a `check` block per line. An empty invoice and
a failed extraction are not the same thing, and the format says which.

---

## Three numbers to remember

**100 % / 100 %** — multi-page merge precision and recall, zero wrong merges
across every run.

**0.974** — TEDS with HunyuanOCR and adaptive extraction. The ceiling for a
perfect choice was 0.976.

**6 %** — the share of lines a human needs to review, containing 100 % of the
numeric errors.

---

## The one caveat to state first

All data is synthetic: one generator, one deformation engine, no real
photograph yet. Saying it before being asked is better than being asked.

The mitigation is planned and specific — print the fake invoices and
photograph them, which preserves the exact ground truth that no real document
allows. It is blocked on printer access, not on method.
